// Excel parsing helpers for bulk client onboarding.
// Uses SheetJS (xlsx). Pure JS — no native deps.

import * as XLSX from "xlsx";

export type ParsedRow = {
  rowIndex: number;
  rawJson: string;
  companyName: string;
  contactName: string;
  email: string;
  phone?: string;
  centerName: string;
  cabinName?: string;
  seats: number;
  rentPerSeat: number;
  securityDeposit: number;
  startDate?: Date;
  incrementPct: number;
  occupiedSeats: number;
  contractFilePath?: string;
  errors: { field: string; message: string }[];
};

function normHeader(h: string): string {
  return String(h).toLowerCase().replace(/\*/g, "").replace(/\s+/g, " ").trim();
}

const COL_MAP: Record<string, string> = {
  "company name": "companyName", "company": "companyName",
  "contact name": "contactName", "contact": "contactName", "primary contact": "contactName",
  "email": "email", "email id": "email", "email address": "email",
  "phone": "phone", "phone number": "phone", "mobile": "phone",
  "center name": "centerName", "centre name": "centerName", "center": "centerName", "centre": "centerName",
  "cabin name": "cabinName", "cabin": "cabinName",
  "seats": "seats", "no of seats": "seats", "number of seats": "seats",
  "rent per seat": "rentPerSeat", "rent/seat": "rentPerSeat", "monthly rent per seat": "rentPerSeat",
  "security deposit": "securityDeposit", "deposit": "securityDeposit", "sd": "securityDeposit",
  "start date": "startDate", "from date": "startDate", "commencement date": "startDate",
  "increment %": "incrementPct", "increment percent": "incrementPct", "increment": "incrementPct",
  "occupied seats": "occupiedSeats", "currently occupied": "occupiedSeats",
  "contract file path": "contractFilePath", "contract path": "contractFilePath", "contract url": "contractFilePath",
};

export function parseExcel(buffer: Buffer): ParsedRow[] {
  const wb = XLSX.read(buffer, { type: "buffer", cellDates: true });
  if (!wb.SheetNames.length) return [];
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows: any[] = XLSX.utils.sheet_to_json(sheet, { defval: "", raw: false });
  const out: ParsedRow[] = [];

  rows.forEach((raw, idx) => {
    const normalized: any = {};
    for (const k of Object.keys(raw)) {
      const h = normHeader(k);
      const mapped = COL_MAP[h];
      if (mapped) normalized[mapped] = raw[k];
    }
    const errors: { field: string; message: string }[] = [];
    const required = (f: string) => {
      const v = normalized[f];
      if (v === undefined || v === null || String(v).trim() === "") errors.push({ field: f, message: `${f} is required` });
    };
    ["companyName", "contactName", "email", "centerName", "seats", "rentPerSeat", "securityDeposit"].forEach(required);

    const num = (v: any) => {
      if (v === "" || v === undefined || v === null) return 0;
      const s = String(v).replace(/,/g, "");
      const n = Number(s);
      return isNaN(n) ? 0 : n;
    };
    const dateOf = (v: any): Date | undefined => {
      if (!v) return undefined;
      if (v instanceof Date) return v;
      const d = new Date(v);
      return isNaN(d.getTime()) ? undefined : d;
    };
    const startDate = dateOf(normalized.startDate);
    if (normalized.startDate && !startDate) errors.push({ field: "startDate", message: "Invalid date format — use YYYY-MM-DD" });

    const email = String(normalized.email || "").trim();
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) errors.push({ field: "email", message: "Invalid email format" });

    const seats = num(normalized.seats);
    if (seats <= 0) errors.push({ field: "seats", message: "Seats must be > 0" });

    const occ = normalized.occupiedSeats !== "" && normalized.occupiedSeats !== undefined ? num(normalized.occupiedSeats) : seats;
    if (occ < 0 || occ > seats) errors.push({ field: "occupiedSeats", message: "Occupied seats must be between 0 and Seats" });

    out.push({
      rowIndex: idx + 2,
      rawJson: JSON.stringify(raw),
      companyName: String(normalized.companyName || "").trim(),
      contactName: String(normalized.contactName || "").trim(),
      email,
      phone: normalized.phone ? String(normalized.phone).trim() : undefined,
      centerName: String(normalized.centerName || "").trim(),
      cabinName: normalized.cabinName ? String(normalized.cabinName).trim() : undefined,
      seats,
      rentPerSeat: num(normalized.rentPerSeat),
      securityDeposit: num(normalized.securityDeposit),
      startDate,
      incrementPct: normalized.incrementPct !== "" && normalized.incrementPct !== undefined ? num(normalized.incrementPct) : 5,
      occupiedSeats: occ,
      contractFilePath: normalized.contractFilePath ? String(normalized.contractFilePath).trim() : undefined,
      errors,
    });
  });
  return out;
}

export function buildTemplateBuffer(centersCsv = "CW Connaught Place, CW Cyber Hub"): Buffer {
  const headers = [
    "Company Name", "Contact Name", "Email", "Phone", "Center Name", "Cabin Name",
    "Seats", "Rent Per Seat", "Security Deposit", "Start Date", "Increment %",
    "Occupied Seats", "Contract File Path",
  ];
  const example = [
    "Acme Pvt Ltd", "Anita Desai", "anita@acme.in", "+91 9000022222",
    "CW Connaught Place", "6-Seater Cabin 1", 6, 8500, 51000, "2025-04-01", 5, 5, "",
  ];
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([headers, example]);
  ws["!cols"] = headers.map(() => ({ wch: 22 }));
  XLSX.utils.book_append_sheet(wb, ws, "Clients");
  const help = XLSX.utils.aoa_to_sheet([
    ["Field", "Required", "Notes"],
    ["Company Name", "Yes", ""],
    ["Contact Name", "Yes", "Primary contact / PIC"],
    ["Email", "Yes", "Will become login email if employee logins added"],
    ["Phone", "No", ""],
    ["Center Name", "Yes", `Must exactly match an existing center, e.g. ${centersCsv}`],
    ["Cabin Name", "No", "Leave blank for open seats"],
    ["Seats", "Yes", "Total seats taken"],
    ["Rent Per Seat", "Yes", "INR (commas OK)"],
    ["Security Deposit", "Yes", "INR"],
    ["Start Date", "No", "YYYY-MM-DD; blank = today on approval"],
    ["Increment %", "No", "Defaults to 5"],
    ["Occupied Seats", "No", "Defaults to Seats"],
    ["Contract File Path", "No", "Optional URL/path of pre-uploaded contract"],
  ]);
  help["!cols"] = [{ wch: 24 }, { wch: 10 }, { wch: 60 }];
  XLSX.utils.book_append_sheet(wb, help, "Help");
  return XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
}
