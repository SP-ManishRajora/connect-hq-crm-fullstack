import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { requireRole } from "@/lib/rbac";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const u = await getSessionUser();
  if (!u || !requireRole(u.role, ["ADMIN", "OWNER", "ACCOUNTS"])) {
    return NextResponse.json({ error: "Accounts/Admin approval required" }, { status: 403 });
  }
  const { decision, remarks } = await req.json();
  const imp = await prisma.bulkClientImport.findUnique({ where: { id: params.id }, include: { rows: true } });
  if (!imp) return NextResponse.json({ error: "Import not found" }, { status: 404 });
  if (imp.status !== "PENDING_APPROVAL") return NextResponse.json({ error: "Already actioned" }, { status: 400 });

  if (decision !== "APPROVE") {
    await prisma.bulkClientImport.update({
      where: { id: imp.id },
      data: { status: "REJECTED", remarks: remarks || null, approvedById: u.id, approvedAt: new Date() },
    });
    return NextResponse.json({ ok: true, status: "REJECTED" });
  }

  let created = 0; const errors: any[] = [];
  for (const row of imp.rows) {
    if (row.status !== "PENDING") continue;
    try {
      const center = await prisma.center.findFirst({ where: { name: row.centerName } });
      if (!center) {
        errors.push({ rowIndex: row.rowIndex, reason: `Center "${row.centerName}" not found` });
        await prisma.bulkClientImportRow.update({ where: { id: row.id }, data: { status: "FAILED", validationErrors: JSON.stringify([{ field: "centerName", message: `Center "${row.centerName}" not found` }]) } });
        continue;
      }
      let cabinId: string | null = null;
      if (row.cabinName) {
        const cab = await prisma.cabin.findFirst({ where: { centerId: center.id, name: row.cabinName } });
        if (!cab) {
          errors.push({ rowIndex: row.rowIndex, reason: `Cabin "${row.cabinName}" not in center "${center.name}"` });
          await prisma.bulkClientImportRow.update({ where: { id: row.id }, data: { status: "FAILED", validationErrors: JSON.stringify([{ field: "cabinName", message: "Cabin not found in this center" }]) } });
          continue;
        }
        cabinId = cab.id;
      }
      const start = row.startDate || new Date();
      const revisionDate = new Date(start); revisionDate.setFullYear(revisionDate.getFullYear() + 1);

      const client = await prisma.client.create({
        data: {
          companyName: row.companyName, contactName: row.contactName,
          email: row.email, phone: row.phone,
          centerId: center.id, cabinId,
          startDate: start,
          occupiedSeats: row.occupiedSeats || row.seats,
          totalCabinSeats: row.seats,
          isLegacy: true,
          legacyImportRowId: row.id,
          contract: {
            create: {
              startDate: start, monthlyRent: row.seats * row.rentPerSeat,
              securityDeposit: row.securityDeposit, incrementPct: row.incrementPct || 5,
              revisionDate, filePath: row.contractFilePath || null,
            },
          },
        },
      });
      if (cabinId) {
        const seats = await prisma.seat.findMany({ where: { cabinId }, orderBy: { number: "asc" } });
        for (let i = 0; i < seats.length; i++) {
          await prisma.seat.update({
            where: { id: seats[i].id },
            data: {
              occupied: i < (row.occupiedSeats || row.seats),
              partialOccupancy: i >= (row.occupiedSeats || row.seats),
              assignedClientId: client.id,
            },
          });
        }
      }
      await prisma.bulkClientImportRow.update({ where: { id: row.id }, data: { status: "CREATED", createdClientId: client.id } });
      created++;
    } catch (e: any) {
      console.error(`[bulk-approve] Row ${row.rowIndex} failed:`, e);
      errors.push({ rowIndex: row.rowIndex, reason: e.message });
      await prisma.bulkClientImportRow.update({ where: { id: row.id }, data: { status: "FAILED", validationErrors: JSON.stringify([{ field: "_", message: e.message }]) } });
    }
  }
  await prisma.bulkClientImport.update({
    where: { id: imp.id },
    data: { status: "PROCESSED", approvedById: u.id, approvedAt: new Date(), remarks: remarks || null },
  });
  return NextResponse.json({ ok: true, created, errors });
}
