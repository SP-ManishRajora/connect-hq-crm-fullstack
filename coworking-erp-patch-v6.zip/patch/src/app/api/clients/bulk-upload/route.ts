import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { parseExcel } from "@/lib/excel";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const u = await getSessionUser();
    if (!u) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

    let form: FormData;
    try { form = await req.formData(); }
    catch (e: any) { return NextResponse.json({ error: `Invalid form data: ${e.message}` }, { status: 400 }); }

    const file = form.get("file") as File | null;
    if (!file) return NextResponse.json({ error: 'No file received. Form field must be named "file".' }, { status: 400 });
    if (!file.name?.match(/\.(xlsx|xls|csv)$/i)) return NextResponse.json({ error: `Expected Excel/CSV file. Got "${file.name}".` }, { status: 400 });

    const buf = Buffer.from(await file.arrayBuffer());
    if (buf.length === 0) return NextResponse.json({ error: "Uploaded file is empty" }, { status: 400 });

    const dir = path.join(process.cwd(), "public", "uploads", "bulk-clients");
    await mkdir(dir, { recursive: true });
    const safe = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "")}`;
    const fullPath = path.join(dir, safe);
    await writeFile(fullPath, buf);
    const publicPath = `/uploads/bulk-clients/${safe}`;

    let parsed: ReturnType<typeof parseExcel>;
    try { parsed = parseExcel(buf); }
    catch (e: any) {
      console.error("[bulk-upload] parseExcel failed:", e);
      return NextResponse.json({ error: `Failed to parse Excel: ${e.message}. Use the template (Download template button).` }, { status: 400 });
    }
    if (parsed.length === 0) return NextResponse.json({ error: "No data rows found. Make sure your Excel has at least one row below the header." }, { status: 400 });

    const validCount = parsed.filter((p) => p.errors.length === 0).length;

    const imp = await prisma.bulkClientImport.create({
      data: { fileName: file.name, filePath: publicPath, uploadedById: u.id, totalRows: parsed.length, validRows: validCount },
    });
    for (const r of parsed) {
      await prisma.bulkClientImportRow.create({
        data: {
          importId: imp.id, rowIndex: r.rowIndex, rawJson: r.rawJson,
          companyName: r.companyName, contactName: r.contactName, email: r.email,
          phone: r.phone, centerName: r.centerName, cabinName: r.cabinName,
          seats: r.seats, rentPerSeat: r.rentPerSeat, securityDeposit: r.securityDeposit,
          startDate: r.startDate, incrementPct: r.incrementPct, occupiedSeats: r.occupiedSeats,
          contractFilePath: r.contractFilePath,
          validationErrors: r.errors.length ? JSON.stringify(r.errors) : null,
          status: r.errors.length ? "FAILED" : "PENDING",
        },
      });
    }
    return NextResponse.json({ id: imp.id, totalRows: parsed.length, validRows: validCount });
  } catch (e: any) {
    console.error("[bulk-upload] Unexpected error:", e);
    const msg = e?.message || String(e);
    const hint = msg.includes("Cannot find module 'xlsx'")
      ? " — run `npm install` (xlsx dep)."
      : (msg.includes("BulkClientImport") || msg.includes("does not exist"))
        ? " — run `npx prisma db push --force-reset && npx tsx prisma/seed.ts` to apply the new schema."
        : "";
    return NextResponse.json({ error: `${msg}${hint}` }, { status: 500 });
  }
}

export async function GET() {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const list = await prisma.bulkClientImport.findMany({
    orderBy: { createdAt: "desc" },
    include: { uploadedBy: true, _count: { select: { rows: true } } },
  });
  return NextResponse.json(list);
}
