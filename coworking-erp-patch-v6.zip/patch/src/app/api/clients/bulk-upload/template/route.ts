import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { buildTemplateBuffer } from "@/lib/excel";

export const runtime = "nodejs";

export async function GET() {
  const centers = await prisma.center.findMany({ select: { name: true } });
  const csv = centers.map((c) => c.name).join(", ") || "Add a center first";
  const buf = buildTemplateBuffer(csv);
  return new NextResponse(buf, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="bulk-clients-template.xlsx"`,
    },
  });
}
