"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { fmtDate } from "@/lib/utils";

const statusColor: Record<string, string> = {
  PENDING_APPROVAL: "bg-amber-100 text-amber-700",
  APPROVED: "bg-emerald-100 text-emerald-700",
  REJECTED: "bg-rose-100 text-rose-700",
  PROCESSED: "bg-blue-100 text-blue-700",
};

export default function BulkClient({ initial, role }: any) {
  const router = useRouter();
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function upload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    setError(null); setUploading(true);
    const fd = new FormData(); fd.append("file", file);
    let r: Response;
    try { r = await fetch("/api/clients/bulk-upload", { method: "POST", body: fd }); }
    catch (err: any) { setUploading(false); setError(`Network error: ${err.message}`); return; }
    setUploading(false);
    if (r.ok) {
      const j = await r.json();
      alert(`Uploaded — ${j.validRows}/${j.totalRows} rows are valid. Submitted to Accounts for approval.`);
      router.push(`/clients/bulk/${j.id}`);
    } else {
      let j: any = {};
      try { j = await r.json(); } catch {}
      setError(j.error || `Upload failed (HTTP ${r.status}). Check the browser console and server logs.`);
    }
    (e.target as HTMLInputElement).value = "";
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <div>
          <h1 className="h1">Bulk Client Onboarding</h1>
          <p className="muted">One-time legacy client import. Upload Excel → goes to Accounts for approval → Clients + Contracts created.</p>
        </div>
        <a href="/api/clients/bulk-upload/template" className="btn-ghost">⬇ Download template (.xlsx)</a>
      </div>

      <div className="card">
        <h2 className="h2">Upload Excel</h2>
        <p className="muted text-xs">Required: Company Name, Contact Name, Email, Center Name, Seats, Rent Per Seat, Security Deposit. Optional: Phone, Cabin Name, Start Date, Increment %, Occupied Seats, Contract File Path.</p>
        <input type="file" accept=".xlsx,.xls,.csv" onChange={upload} disabled={uploading} className="mt-3" />
        {uploading && <p className="text-sm text-brand-600 mt-2">Uploading & parsing…</p>}
        {error && (
          <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded text-sm text-rose-800">
            <strong>Upload failed</strong>
            <div className="mt-1">{error}</div>
            <details className="mt-2 text-xs">
              <summary className="cursor-pointer">Common causes / fixes</summary>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li><strong>404</strong>: this patch's files were not copied. Re-apply the patch (copy <code>patch/</code> onto your project) and restart <code>npm run dev</code>.</li>
                <li><code>npm install</code> not run after applying the patch (needs <code>xlsx</code>).</li>
                <li>Prisma schema not migrated. Run <code>npx prisma db push --force-reset && npx tsx prisma/seed.ts</code>.</li>
                <li>Excel column headers don't match — use the template above.</li>
                <li>Date format invalid — use YYYY-MM-DD or leave Start Date blank.</li>
                <li>Center Name in Excel doesn't match an existing center.</li>
              </ul>
            </details>
          </div>
        )}
      </div>

      <div className="card overflow-x-auto">
        <h2 className="h2 mb-2">Import history</h2>
        <table className="table">
          <thead><tr><th>Date</th><th>File</th><th>Uploaded By</th><th>Rows</th><th>Valid</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {initial.map((i: any) => (
              <tr key={i.id}>
                <td>{fmtDate(i.createdAt)}</td>
                <td className="text-xs"><a href={i.filePath} target="_blank" className="text-brand-600">{i.fileName}</a></td>
                <td>{i.uploadedBy?.name}</td>
                <td>{i.totalRows}</td>
                <td>{i.validRows}</td>
                <td><span className={`badge ${statusColor[i.status]}`}>{i.status}</span></td>
                <td><Link href={`/clients/bulk/${i.id}`} className="text-brand-600 text-xs">Review →</Link></td>
              </tr>
            ))}
            {initial.length === 0 && <tr><td colSpan={7} className="text-center text-gray-400 py-8">No imports yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
