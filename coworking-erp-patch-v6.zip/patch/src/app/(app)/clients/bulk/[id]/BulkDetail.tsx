"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { fmtDate, fmtINR } from "@/lib/utils";

const isAccounts = (role: string) => ["ADMIN", "OWNER", "ACCOUNTS"].includes(role);
const rowStatusColor: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-700",
  CREATED: "bg-emerald-100 text-emerald-700",
  FAILED: "bg-rose-100 text-rose-700",
  SKIPPED: "bg-gray-100 text-gray-700",
};

export default function BulkDetail({ imp, role }: any) {
  const router = useRouter();
  const canApprove = isAccounts(role) && imp.status === "PENDING_APPROVAL";

  async function decide(decision: "APPROVE" | "REJECT") {
    let remarks = "";
    if (decision === "REJECT") { remarks = prompt("Reason for rejection:") || ""; if (!remarks) return; }
    else if (!confirm(`Approve & create ${imp.rows.filter((r: any) => r.status === "PENDING").length} clients with contracts?`)) return;
    const r = await fetch(`/api/clients/bulk-upload/${imp.id}/approve`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ decision, remarks }),
    });
    if (r.ok) { const j = await r.json(); alert(decision === "APPROVE" ? `Created ${j.created} clients. ${j.errors?.length || 0} failed.` : "Rejected."); router.refresh(); }
    else { const j = await r.json(); alert(j.error || "Failed"); }
  }

  return (
    <div className="space-y-4">
      <Link href="/clients/bulk" className="text-sm text-brand-600">← Back to imports</Link>
      <div className="flex justify-between items-start flex-wrap gap-3">
        <div>
          <h1 className="h1">Import: {imp.fileName}</h1>
          <p className="muted">Uploaded by {imp.uploadedBy?.name} on {fmtDate(imp.createdAt)} · <a href={imp.filePath} className="text-brand-600">view source file</a></p>
          <p className="muted">Status: <span className={`badge ${imp.status === "PROCESSED" ? "bg-blue-100 text-blue-700" : imp.status === "REJECTED" ? "bg-rose-100 text-rose-700" : imp.status === "PENDING_APPROVAL" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>{imp.status}</span></p>
          {imp.remarks && <p className="muted text-xs">Remarks: {imp.remarks}</p>}
        </div>
        {canApprove && (
          <div className="flex gap-2">
            <button className="btn-primary" onClick={() => decide("APPROVE")}>Approve & Create</button>
            <button className="btn-ghost" onClick={() => decide("REJECT")}>Reject</button>
          </div>
        )}
        {!isAccounts(role) && imp.status === "PENDING_APPROVAL" && <p className="muted text-xs italic">Awaiting approval from Accounts.</p>}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="card"><div className="muted text-xs">Total rows</div><div className="text-2xl font-bold">{imp.totalRows}</div></div>
        <div className="card"><div className="muted text-xs">Valid</div><div className="text-2xl font-bold text-emerald-700">{imp.validRows}</div></div>
        <div className="card"><div className="muted text-xs">Created</div><div className="text-2xl font-bold text-blue-700">{imp.rows.filter((r: any) => r.status === "CREATED").length}</div></div>
        <div className="card"><div className="muted text-xs">Failed</div><div className="text-2xl font-bold text-rose-700">{imp.rows.filter((r: any) => r.status === "FAILED").length}</div></div>
      </div>

      <div className="card overflow-x-auto">
        <table className="table">
          <thead><tr><th>#</th><th>Company</th><th>Contact</th><th>Email</th><th>Center / Cabin</th><th>Seats</th><th>Rent/seat</th><th>Start</th><th>Status</th><th>Errors</th></tr></thead>
          <tbody>
            {imp.rows.map((r: any) => {
              const errs = r.validationErrors ? JSON.parse(r.validationErrors) as { field: string; message: string }[] : [];
              return (
                <tr key={r.id} className={errs.length ? "bg-rose-50" : ""}>
                  <td>{r.rowIndex}</td>
                  <td className="font-medium">{r.companyName}{r.createdClientId && <Link className="ml-1 text-xs text-brand-600" href={`/clients/${r.createdClientId}`}>→</Link>}</td>
                  <td>{r.contactName}</td>
                  <td className="text-xs">{r.email}</td>
                  <td>{r.centerName}{r.cabinName ? ` / ${r.cabinName}` : ""}</td>
                  <td>{r.seats}</td>
                  <td>{fmtINR(r.rentPerSeat)}</td>
                  <td>{r.startDate ? fmtDate(r.startDate) : "—"}</td>
                  <td><span className={`badge ${rowStatusColor[r.status]}`}>{r.status}</span></td>
                  <td className="text-xs text-rose-700">{errs.map((e, i) => <div key={i}>{e.field}: {e.message}</div>)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
