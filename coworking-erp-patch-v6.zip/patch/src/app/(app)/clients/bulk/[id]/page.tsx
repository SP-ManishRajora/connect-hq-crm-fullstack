import { prisma } from "@/lib/db";
import { notFound } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import BulkDetail from "./BulkDetail";

export const dynamic = "force-dynamic";

export default async function Page({ params }: { params: { id: string } }) {
  const me = await getSessionUser();
  const imp = await prisma.bulkClientImport.findUnique({
    where: { id: params.id },
    include: { uploadedBy: true, rows: { orderBy: { rowIndex: "asc" } } },
  });
  if (!imp) return notFound();
  return <BulkDetail imp={JSON.parse(JSON.stringify(imp))} role={me?.role || ""} />;
}
