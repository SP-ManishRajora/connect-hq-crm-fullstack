import { prisma } from "@/lib/db";
import BulkClient from "./BulkClient";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function Page() {
  const me = await getSessionUser();
  const imports = await prisma.bulkClientImport.findMany({
    orderBy: { createdAt: "desc" },
    include: { uploadedBy: true, _count: { select: { rows: true } } },
  });
  return <BulkClient initial={JSON.parse(JSON.stringify(imports))} role={me?.role || ""} />;
}
